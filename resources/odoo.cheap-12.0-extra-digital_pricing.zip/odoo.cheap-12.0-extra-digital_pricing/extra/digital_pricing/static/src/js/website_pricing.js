odoo.define('digital_pricing.website_pricing', function (require) {
"use strict";

var core = require('web.core');
var ajax = require('web.ajax');
var sAnimation = require('website.content.snippets.animation');
var _t = core._t;

sAnimation.registry.js_get_pricing = sAnimation.Class.extend({
    selector : '.js_get_pricing',

    start: function () {
        var self = this;
        // var limit = self.$target.data('postsLimit') || 3;
        var categoryID = self.$target.data('filterByCategoryId');
        var template = self.$target.data('template') || 'digital_pricing.s_latest_products';

        this.$target.empty(); // Compatibility with db that saved content inside by mistake
        this.$target.attr('contenteditable', 'False'); // Prevent user edition

        var domain = [['is_pricing_product', '=', true]];
        if (categoryID) {
            domain.push(['categ_id', '=', parseInt(categoryID)]);
        }

        var def = $.Deferred();
        this._rpc({
            route: '/pricing/render_products',
            params: {
                template: template,
                domain: domain,
                categ_id: categoryID,
                // limit: limit,
            },
        }).then(function (products) {
            var $products=  $(products).find('.pricing_app');
            // var $posts = $(posts).filter('.s_latest_posts_post');
            if (!$products.length) {
                self.$target.append($('<div/>', {class: 'col-md-4 offset-md-2'})
                    .append($('<div/>', {
                        class: 'alert alert-warning alert-dismissible text-center',
                        text: _t("No products was found. Make sure your products are pricing product."),
                    })));
                return;
            }
            self.$target.html(products);

            self.$target.find('.pricing_app input[type="checkbox"]').change(function (e) {
                function get_depends(o) {
                    return (o.data('app-depends') || '').split(',').filter(function(n){ return n != "";});
                }

                var checkbox = $(e.target);
                var depends = get_depends(checkbox);
                if (checkbox.prop('checked')) {
                    var product_ids = [checkbox.attr('product_variant_id')];
                    if (depends.length) {
                        $.each(depends, function(i, j) {
                            $("input[data-app-name='"+ j.trim() +"']").prop('checked', true);
                            product_ids.push($("input[data-app-name='"+ j.trim() +"']").attr('product_variant_id'));
                        });
                    }

                    ajax.jsonRpc('/pricing/json_cart', 'call', {
                        product_id: checkbox.attr('product_variant_id'),
                        product_ids: product_ids,
                        operation: 'add',
                        kwargs: {context: this.context,}
                    })
                    .then(function (values) {
                        if (values.cart_quantity) {
                            $('#my_cart').removeClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
                            $('.pricing_cart_box:first').show();
                        } else {
                            $('#my_cart').addClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
                            $('.pricing_cart_box:first').hide();
                        }
                        $('.pricing_cart_box #cart').html(values.tmpl);
                    });
                }
                else if (!checkbox.prop('checked')) {
                    var product_ids = [checkbox.attr('product_variant_id')];
                    var depending = _.filter($("input[data-app-depends]"), function(o) {
                        return _.indexOf(get_depends($(o)), checkbox.data('app-name')) > -1;
                    });
                    $.each(depending, function(i,j) {
                       $(j).prop('checked', false);
                       product_ids.push($(j).attr('product_variant_id'));
                    });

                    ajax.jsonRpc('/pricing/json_cart', 'call', {
                        product_id: checkbox.attr('product_variant_id'),
                        product_ids: product_ids,
                        operation: 'remove',
                        kwargs: {context: this.context,}
                    })
                    .then(function (values) {
                        if (values.cart_quantity) {
                            $('#my_cart').removeClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
                            $('.pricing_cart_box:first').show();
                        } else {
                            $('#my_cart').addClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
                            $('.pricing_cart_box:first').hide();
                        }
                        $('.pricing_cart_box #cart').html(values.tmpl);
                    });

                }

                var oo = $(".pricing_app_checkbox");
                oo.each( function(i, o) {
                    var closest = $($(o).closest(".pricing_app"));
                    closest.toggleClass("selected", $(o).prop('checked'));
                });
            });

            ajax.jsonRpc('/pricing/json_cart', 'call', {operation: 'view'})
            .then(function (values) {
                if (!values.no_order) {
                    $.each(values.lines, function(index, value){
                        var $checkbox = $('.pricing_app').find('input[product_variant_id=' + value + ']');
                        if ($checkbox.length){
                            $checkbox.prop('checked', true).change();
                        }
                    });

                    if (values.cart_quantity) {
                        $('#my_cart').removeClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
                        $('.pricing_cart_box:first').show();
                    } else {
                        $('#my_cart').addClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
                        $('.pricing_cart_box:first').hide();
                    }
                    $('.pricing_cart_box #cart').html(values.tmpl);
                } else {
                    $('.pricing_cart_box:first').hide();
                }
            });

        }, function (e) {
            if (self.editableMode) {
                self.$target.append($('<p/>', {
                    class: 'text-danger',
                    text: _t("An error occured with this latest posts block. If the problem persists, please consider deleting it and adding a new one"),
                }));
            }
        }).always(def.resolve.bind(def));
        return $.when(this._super.apply(this, arguments), def);
    },
    /**
     * @override
     */
    destroy: function () {
        this.$target.empty();
        this._super.apply(this, arguments);
    },
});

});
