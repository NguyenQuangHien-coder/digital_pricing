odoo.define('digital_pricing.editor', function (require) {
'use strict';

var core = require('web.core');
var rpc = require('web.rpc');
var sOptions = require('web_editor.snippets.options');
var _t = core._t;

sOptions.registry.js_get_products = sOptions.Class.extend({
    /**
     * @override
     */
    start: function () {
        var self = this;

        var def = rpc.query({
            model: 'product.template',
            method: 'get_pricing_category',
            args: ['', []],
        }).then(function (categories) {
            var $menu = self.$el.find('[data-filter-by-category-id="0"]').parent();
            _.each(categories, function (category) {
                $menu.append($('<a/>', {
                    class: 'dropdown-item',
                    'data-filter-by-category-id': category.id,
                    'data-no-preview': 'true',
                    text: category.name,
                }));
            });
        });

        return $.when(this._super.apply(this, arguments), def);
    },

    //--------------------------------------------------------------------------
    // Options
    //--------------------------------------------------------------------------

    /**
     * @see this.selectClass for parameters
     */
    filterByCategoryId: function (previewMode, value, $opt) {
        value = parseInt(value);
        this.$target.attr('data-filter-by-category-id', value).data('filterByCategoryId', value);
        this.trigger_up('animation_start_demand', {
            editableMode: true,
            $target: this.$target,
        });
    },

    //--------------------------------------------------------------------------
    // Private
    //--------------------------------------------------------------------------

    /**
     * @override
     */
    _setActive: function () {
        var self = this;
        this._super.apply(this, arguments);
        this.$('[data-filter-by-category-id]').addBack('[data-filter-by-category-id]')
            .removeClass('active')
            .filter(function () {
                return (self.$target.data('filterByCategoryId') || 0) == $(this).data('filterByCategoryId');
            })
            .addClass('active');
    },
});
});
