odoo.define('digital_pricing.custom', function(require) {
"use strict";

    // require('web.dom_ready');

    // var core = require('web.core');
    // var ajax = require('web.ajax');
    // var Widget = require('web.Widget');
    // var utils = require('web.utils');
    // var sAnimation = require('website.content.snippets.animation');

    // $('.pricing_app input[type="checkbox"]').change(function (e) {
    //     function get_depends(o) {
    //         return (o.data('app-depends') || '').split(',').filter(function(n){ return n != "";});
    //     }

    //     var checkbox = $(e.target);
    //     var depends = get_depends(checkbox);
    //     if (checkbox.prop('checked') && depends.length) {
    //         $.each(depends, function(i, j) {
    //             $("input[data-app-name="+ j +"]").prop('checked', true).change();
    //         });
    //     }
    //     else if (!checkbox.prop('checked')) {
    //         var depending = _.filter($("input[data-app-depends]"), function(o) {
    //             return _.indexOf(get_depends($(o)), checkbox.data('app-name')) > -1;
    //         });
    //         $.each(depending, function(i,j) {
    //            $(j).prop('checked', false).change();
    //         });
    //     }

    //     var oo = $(".pricing_app_checkbox");
    //     oo.each( function(i, o) {
    //         var closest = $($(o).closest(".pricing_app"));
    //         closest.toggleClass("selected", $(o).prop('checked'));
    //     });

    //     if (checkbox.prop('checked')) {
    //         ajax.jsonRpc('/pricing/json_cart', 'call', {
    //             product_id: checkbox.attr('product_tmpl_id'),
    //             operation: 'add',
    //             kwargs: {context: this.context,}
    //         })
    //         .then(function (values) {
    //             if (values.cart_quantity) {
    //                 $('#my_cart').removeClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
    //                 $('.pricing_cart_box:first').show();
    //             } else {
    //                 $('#my_cart').addClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
    //                 $('.pricing_cart_box:first').hide();
    //             }
    //             $('.pricing_cart_box #cart').html(values.tmpl);
    //         });
    //     } else {
    //         ajax.jsonRpc('/pricing/json_cart', 'call', {
    //             product_id: checkbox.attr('product_tmpl_id'),
    //             operation: 'remove',
    //             kwargs: {context: this.context,}
    //         })
    //         .then(function (values) {
    //             if (values.cart_quantity) {
    //                 $('#my_cart').removeClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
    //                 $('.pricing_cart_box:first').show();
    //             } else {
    //                 $('#my_cart').addClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
    //                 $('.pricing_cart_box:first').hide();
    //             }
    //             $('.pricing_cart_box #cart').html(values.tmpl);
    //         });
    //     }
    // });

    // ajax.jsonRpc('/pricing/json_cart', 'call', {operation: 'view'})
    // .then(function (values) {
    //     if (values.cart_quantity) {
    //         $('#my_cart').removeClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
    //         $('.pricing_cart_box:first').show();
    //     } else {
    //         $('#my_cart').addClass('d-none').find('.my_cart_quantity').text(values.cart_quantity);
    //         $('.pricing_cart_box:first').hide();
    //     }
    //     $('.pricing_cart_box #cart').html(values.tmpl);
    // });

});
