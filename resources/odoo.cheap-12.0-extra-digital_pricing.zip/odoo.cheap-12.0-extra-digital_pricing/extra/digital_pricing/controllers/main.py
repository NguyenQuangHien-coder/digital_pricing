# -*- coding: utf-8 -*-

import logging
from odoo import fields, http, tools, _
from odoo.http import request

_logger = logging.getLogger(__name__)


class digital_pricing(http.Controller):
    @http.route('/pricing/json_cart', type='json', auth="public", website=True)
    def pricing_json_cart(self, **post):
        if (post.get('operation') == 'add'):
            order = request.website.sale_get_order(force_create=1)
        else:
            order = request.website.sale_get_order()

        if not order:
            return {'no_order': True}

        if order.state != 'draft':
            request.website.sale_reset()
            return {}

        value = {}
        if post.get('operation') == 'add':
            product_ids = map(int, post.get('product_ids'))
            for product_id in product_ids:
                order._cart_update(product_id=product_id, add_qty=None, set_qty=1)
        elif post.get('operation') == 'remove':
            product_ids = map(int, post.get('product_ids'))
            for product_id in product_ids:
                order._cart_update(product_id=product_id, add_qty=None, set_qty=0)

        if not order.cart_quantity:
            request.website.sale_reset()
            value['cart_quantity'] = order.cart_quantity
            value['tmpl'] = ''
            value['lines'] = []
            return value

        order = request.website.sale_get_order()
        value['cart_quantity'] = order.cart_quantity
        to_currency = order.pricelist_id.currency_id
        value['lines'] = order.order_line.mapped('product_id').ids

        total_apps = order.order_line.filtered(
            lambda o: not o.product_id.is_package_product).filtered(
            lambda o: o.product_id.is_pricing_product)
        total_apps_amount = sum([line.price_total for line in total_apps])

        value['tmpl'] = request.env['ir.ui.view'].render_template(
            "digital_pricing.pricing_cart", {
                'order': order,
                'total_apps': len(total_apps),
                'total_apps_amount': total_apps_amount,
                'to_currency': to_currency
            }
        )
        value['no_order'] = False
        return value

    @http.route(['/pricing/render_products'], type='json', auth='public', website=True)
    def render_pricing_products(self, template, domain, categ_id=None, limit=None, order='id desc'):
        products = request.env['product.template'].search(domain, limit=limit, order=order)
        category = None
        if categ_id:
            category_id = categ_id and int(categ_id)
            category = request.env['product.category'].browse(category_id)

        return request.env.ref(template).render({'products': products, 'category': category})
