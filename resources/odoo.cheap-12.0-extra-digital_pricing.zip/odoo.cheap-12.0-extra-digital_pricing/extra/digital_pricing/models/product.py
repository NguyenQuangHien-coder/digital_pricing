# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools, _


class ProductTemplate(models.Model):
    _inherit = "product.template"

    is_pricing_product = fields.Boolean('Digital Product')
    icon = fields.Binary(
        "Icon", attachment=True,
        help="This field holds the image used as icon for the pricing, limited to 128pxx128px.")
    dependency_modules = fields.Many2many(
        'product.template', 'product_dependency_module_rel', 'src_id', 'dest_id',
        string='Dependency Modules')
    is_package_product = fields.Boolean('Package Product')
    brief_description = fields.Text('Package Description')

    @api.multi
    def get_pricing_category(self):
        products = self.search([('is_pricing_product', '=', True)])
        categories_list = products.mapped('categ_id')
        categories = []
        for category in categories_list:
            categories.append({'id': category.id, 'name': category.name})
        return categories
