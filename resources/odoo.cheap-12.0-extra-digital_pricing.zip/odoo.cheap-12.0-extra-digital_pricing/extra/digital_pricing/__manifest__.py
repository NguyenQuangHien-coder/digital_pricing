# -*- coding: utf-8 -*-
# Copyright (C) Kanak Infosystems LLP.

{
    'name': 'Digital Pricing Snippet',
    'version': '1.0',
    'summary': 'The extand product pricing snippet for digital product',
    'description': "Normal odoo support for ditial product as a service, but not have function to order as a software, Digital Pricing Snippet help you out to sell product as a software",
    'license': 'OPL-1',
    'author': 'Odoo.Cheap, saas tools, Kanak Infosystems LLP',
    'category': 'website',
    'depends': ['website_sale'],
    'data': [
        'data/data.xml',
        'views/views.xml',
        'views/assets.xml',
        'views/templates.xml',
        'views/snippets_templates.xml',
    ],
    'installable': True,
    'application': True,
}
